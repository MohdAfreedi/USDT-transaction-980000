// Load servers from localStorage
let servers = JSON.parse(localStorage.getItem("dbServers")) || [];

// Render table when page loads
render();

// ----------------------------
// Render Table
// ----------------------------
function render() {

    const table = document.getElementById("serverTable");

    table.innerHTML = "";

    servers.forEach((s, index) => {

        table.innerHTML += `
        <tr>

            <td>${s.name}</td>

            <td>${s.pool}</td>

            <td>${s.ocpu}</td>

            <td>${s.memory} GB</td>

            <td class="${s.status === "Running" ? "running" : "stopped"}">
                ● ${s.status}
            </td>

            <td>${s.region}</td>

            <td>

                <button class="action" onclick="openServer(${index})">
    Open
</button>

                <button class="action">Restart</button>

                <button class="delete"
                        onclick="deleteServer(${index})">
                    Delete
                </button>

            </td>

        </tr>
        `;

    });

}

// ----------------------------
// Open Popup
// ----------------------------
function openPopup() {

    document.getElementById("popup").style.display = "flex";

}

// ----------------------------
// Close Popup
// ----------------------------
function closePopup() {

    document.getElementById("popup").style.display = "none";

}

// ----------------------------
// Create Database Server
// ----------------------------
function createServer() {

    const server = {

        name: document.getElementById("serverName").value,

        pool: document.getElementById("pool").value,

        ocpu: document.getElementById("ocpu").value,

        memory: document.getElementById("memory").value,

        status: "Running",

        region: document.getElementById("region").value

    };

    servers.push(server);

    localStorage.setItem("dbServers", JSON.stringify(servers));

    render();

    closePopup();

}

// ----------------------------
// Delete Server
// ----------------------------
function deleteServer(index) {

    if (confirm("Delete this Database Server?")) {

        servers.splice(index, 1);

        localStorage.setItem("dbServers", JSON.stringify(servers));

        render();

    }

}
function openServer(index){

localStorage.setItem(

"selectedServer",

JSON.stringify(servers[index])

);

window.location="database-server-details.html";

}