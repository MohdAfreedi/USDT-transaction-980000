const express = require("express");
const path = require("path");

const app = express();

// Serve static files
app.use(express.static(path.join(__dirname, "public")));

// Home page
app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "public", "index.html"));
});

const PORT = 3000;

app.listen(PORT, () => {
    console.log("==================================");
    console.log("   Oracle Cloud Started");
    console.log("==================================");
    console.log(`Server Running: http://localhost:${PORT}`);
});